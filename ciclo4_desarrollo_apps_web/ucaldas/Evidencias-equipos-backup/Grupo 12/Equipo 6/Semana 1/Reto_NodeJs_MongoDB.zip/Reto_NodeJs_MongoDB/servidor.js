const express = require('express');
const mongoose = require('mongoose')
const PersonSchema = require('./modelos/persona.js');

const app = express();
const router = express.Router();

app.use(express.urlencoded({extended: true}));
app.use(express.json());


// CONEXION A BASE DE DATOS
    mongoose.connect("mongodb+srv://prog_web:ProgWebMintic2022@clusterprogweb.g3dxi.mongodb.net/Reto2?retryWrites=true&w=majority");

//*************   OPERACIONES CRUD   **********************************************************************

router.get('/', (req, res) => {
        res.send("Inicio de API Reto NodeJs & MongoDB..."); //esto es lo que mostrará en el navegador del servidor localhost:3000
});
    
//*************   ADD DATOS AL MongoDB  ***************************************************************
router.post('/persona', (req, res) => {
    let newPerson = new PersonSchema({
        tipoDoc: req.body.tipoDoc,
        numDoc: req.body.numDoc,
        nomPersona: req.body.nombre,
        apePersona: req.body.apellido,
        dirPersona: req.body.direccion,
        emailPersona: req.body.email,
        fijoPersona: req.body.telFijo,
        movilPersona: req.body.teMovil,
        webPersona: req.body.web,
        perfilPersona: req.body.perfil
    });

    newPerson.save(function(err, datos){
        if(err){
            console.log(err);
        }
         res.send("El postulante ha sido almacenado Correctamente...");
            
    });
});

//*************    QUERY DATOS AL MongoDB     **********************************************************
router.get('/persona', (req, res) => {
    PersonSchema.find(function(err, datos){
        if(err){
            console.log("Error leyendo las tareas...");
        }else{
            res.send(datos);
        }
    });
});
    
//*************    DELETE DATOS AL MongoDB     *******************************************************
router.delete('/persona/:numDoc?', (req, res) => {
    const id = req.params.numDoc;
    PersonSchema.findByIdAndDelete(id)
    .then(data => {
        if(!data){
            res.status(404).send("No se encontro una persona con ese número de documento "+id);
        }else{
            res.send("Persona se elimino");
        }
    })
    .catch(err => {
        res.status(500).send("La persona con el número de documento: "+id+", no se ha podido eliminar")
    })
})

//*************    UPDATE DATOS AL MongoDB     *******************************************************
    router.post('/', (req, res) => {
       
    });

router.put('/persona/:numDoc', (req,res) => {
    const id = req.params.numDoc;
    PersonSchema.findByIdAndUpdate(id, req.body, {useFindAndModify: false})
    .then(data => {
        if(!data){
            res.status(404).send("La persona que intento actualizar no se encontro")
        }else res.send("La persona ha sido actualizada")
    })
    .catch(err => {
        res.status(500).send("Error al acutualizar la persona con el id="+id);
    })
})


app.use(router);
app.listen(3000, () => {
    console.log("Servidor Inicializado...")
});