const  mongoose = require('mongoose');

let PersonSchema = new mongoose.Schema({
    tipoDoc: String,
    numDoc: String,
    nomPersona: String,
    apePersona: String,
    dirPersona: String,
    emailPersona: String,
    fijoPersona: String,
    movilPersona: String,
    webPersona: String,
    perfilPersona: String
});

module.exports = mongoose.model('persona', PersonSchema, 'Personas');