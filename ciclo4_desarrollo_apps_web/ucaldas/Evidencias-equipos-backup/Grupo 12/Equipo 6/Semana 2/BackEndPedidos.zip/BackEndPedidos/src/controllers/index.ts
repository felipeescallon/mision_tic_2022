export * from './ping.controller';
export * from './pedido-persona.controller';
export * from './persona-pedido.controller';
export * from './pedido-producto.controller';
export * from './persona.controller';
export * from './producto.controller';
export * from './pedido.controller';
