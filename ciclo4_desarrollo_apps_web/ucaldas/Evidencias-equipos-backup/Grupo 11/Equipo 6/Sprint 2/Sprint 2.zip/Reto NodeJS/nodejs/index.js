//import { env } from 'process';

/* Bienvenida */
console.log("Bienvenido a este reto");

/* Definición de variables */

const express = require("express");
const mongoose = require("mongoose");
const personaSchema = require("./modelos/persona.js");
const app = express();
const router = express.Router();
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

require('dotenv').config();
console.log('Your environment variable TWILIO_ACCOUNT_SID has the value: ', process.env.TWILIO_ACCOUNT_SID);

/* Conexión a la Base de Datos */
mongoose.connect(
  "mongodb+srv://prog_web:ProgWebMintic2022@clusterprogweb.tfru8.mongodb.net/RetoNodeJS"
);

/* Operaciones CRUD */

/* Mensaje de inicio */
router.get("/", (req, res) => {
  res.send("Esta es mi API");
});

/* Petición de personas */
router.get("/persona", (req, res) => {
  tareaSchema.find(function (err, datos) {
    if (err) {
      console.log(err);
    } else {
      res.send(datos);
    }
  });
});

/* Agregar  personas */
router.post("/persona", (req, res) => {
  let nuevaPersona = new personaSchema({
    idPersona: req.body.idPersona,
    tipoDocumento: req.body.tipoDocumento,
    numeroDocumento: req.body.numeroDocumento,
    nombres: req.body.nombres,
    apellidos: req.body.apellidos,
    direccion: req.body.direccion,
    correoElectronico: req.body.correoElectronico,
    telefonoFijo: req.body.telefonoFijo,
    telefonoCelular: req.body.telefonoCelular,
    sitioWeb: req.body.sitioWeb,
    descripcion: req.body.descripcion,
  });

  nuevaPersona.save(function (err, datos) {
    if (err) {
      console.log(err);
    }
    res.send("La nueva persona se ha agregado correctamente");
  });
});

app.use(router);
app.listen(3000, () => {
  console.log("El servidor está opertivo y se comunica por medio del puerto 3000");
});

/* Envío de SMS con Twilio */
router.get("/sendSMS", (req, res) => {

  const accountSid = process.env.TWILIO_ACCOUNT_SID; //Asignación de 
  const authToken = process.env.TWILIO_AUTH_TOKEN;
  const origen = process.env.TELEFONO_ORIGEN
  const client = require('twilio')(accountSid, authToken);

  client.messages
    .create({
      body: req.body.mensaje,
      from: origen,
      to: '+57' + req.body.destino
    })

    .then(message => console.log('El id del SMS es: ' + message.sid))

    .catch(err => {
      res.status(500).send('Error al enviar el SMS')
    })

});

/* Envío de Correo electrónico con Sendgrid */
router.get("/sendEmail", (req, res) => {

  const sgMail = require('@sendgrid/mail')
  sgMail.setApiKey(process.env.SENDGRID_API_KEY)

  const newMessage = {
    to: req.body.destino,
    from: '@gmail.com',
    subject: req.body.asunto,
    html: req.body.mensaje
  }

  sgMail
    .send(newMessage)
    .then(() => {
      console.log('Correo electrónico enviado correctamente.')
    })
    .catch((error) => {
      console.error(error)
    })

});