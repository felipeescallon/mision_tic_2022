const mongoose = require("mongoose");

let personaSchema = new mongoose.Schema({
  idPersona: Number,
  tipoDocumento: String,
  numeroDocumento: String,
  nombres: String,
  apellidos: String,
  direccion: String,
  correoElectronico: String,
  telefonoFijo: String,
  telefonoCelular: String,
  sitioWeb: String,
  descripcion: String,
});

module.exports = mongoose.model("persona", personaSchema, "Personas");
