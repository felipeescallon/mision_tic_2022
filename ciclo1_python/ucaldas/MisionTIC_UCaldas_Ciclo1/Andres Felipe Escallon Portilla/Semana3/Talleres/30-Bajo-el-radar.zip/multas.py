""" Modulo Multas
    Funciones para el cálculo de multas
    de tránsito 
    Oscar Franco-Bedoya
    Mayo 10-2021 """
# Definición de Funciones
#======================================================================
#          E S P A C I O    D E    T R A B A J O     A L U M N O
# ====================================================================
def multar_velocidad(distancia_uno, distancia_dos,tiempo):
  #TODO: Documentar función 
  texto_multa=""
  #TODO: Implementar función
  return texto_multa

def multar_alcoholemia(grado_alcohol):
#TODO: Documentar función 
  texto_multa=""
  #TODO: Implementar función
  return texto_multa


