""" Programa Apoyo multas#
    incorpora al modulo multas.py
    Oscar Franco-Bedoya
    Mayo 3-2021 """

#---------------- Zona librerias------------
import multas.py as mult

#======================================================================
#          E S P A C I O    D E    T R A B A J O     A L U M N O
# ====================================================================


#======================================================================
#   Algoritmo principal Punto de entrada a la aplicación (Conquistar)
# =====================================================================
