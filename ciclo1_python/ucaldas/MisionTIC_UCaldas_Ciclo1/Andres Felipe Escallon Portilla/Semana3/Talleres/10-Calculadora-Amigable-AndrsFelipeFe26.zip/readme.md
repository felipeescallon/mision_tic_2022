# La calculadora amigable
En un laboratorio anterior creamos una aplicación que realizaba las 4 operaciones aritméticas (suma, resta, multiplicación división) y este trabajo lo vamos a reutilizar en este proyecto. Se encuentra en el archivo `calculadora_aritmetica.py` puedes consultarlo en la ventana Files ya que se encuentra como un módulo que puedes utilizar en el archivo main.

## ¿Que debo hacer?
El programa del laboratorio calculaba las 4 operaciones aritméticas una después de otra. Ahora queremos que el programa solo calcule una operación que sea seleccionada por el usuario, es decir, además de pedir los operandos debemos pedir el operador y solo realizar la operación que se indique.
En el archivo main.py hay un codigo base para trabajar

### Algo mas
El usuario anterior a detectado que cuando el segundo operando es cero se genera un error al hacer la división, ¿puedes solucionar este impase aprovechando tus conocimientos en el manejo de condicionales? 