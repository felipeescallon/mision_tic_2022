""" Programa para apoyar al marinero Seijo
    Oscar Franco-Bedoya
    Mayo 3-2021 """

import utilidades as util

def probar_funciones():
  criatura= util.aparecer_criatura()
  direccion=util.aparecer_direccion()
  print(criatura, direccion)

#======================================================================
#   Algoritmo principal Punto de entrada a la aplicación (Conquistar)
# =====================================================================

# Ejecuta el programa varias veces para ver su funcionamiento

probar_funciones()





