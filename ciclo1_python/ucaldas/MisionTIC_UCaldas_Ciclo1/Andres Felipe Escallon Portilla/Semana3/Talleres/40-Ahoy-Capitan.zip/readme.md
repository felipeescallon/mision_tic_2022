# Ahoy, Capitan
El capitán del barco pirata Royal Fortune, el famoso Bartholomew Robert ha designado al jóven marinero Seijo Alonso para que sirva de vigía en el mástil principal. Esto es lo que le ha dicho (gritado) el capitán:

Tu misión es simple marinero, pero importante para la tripulación, cuando veas alguna de estas criaturas debes gritarlo de esta manera, muy muy muy fuerte:
+	Ahoy! capitán, un Kraken
+	Ahoy! capitán, unas Sirenas
+	Ahoy! capitán, una Ballena
+	Ahoy! capitán, un Hipocampo
+	Ahoy! capitán, una Macaraprono
+	Ahoy! capitán, un Pulpo
+	Ahoy! capitán, unos Leviatanes
+	Ahoy! capitán, Unas Hidras

Tu vida va en ello marinero, debes pronunciarlos con el articulo correcto de acuerdo a su especie (uno, una, unos, unas), pero  si te equivocas: saltaras desde cubierta. 

Otra cosa vigia Seijo, debes además gritar la dirección del barco por la que aparece la criatura
+	A babor
+	A estribor
+	Por la proa
+	Por la popa

# ¿Como ayudamos a Seijo?
La mejor ayuda que podemos ofrecerle al joven marinero es un programa que dada la criatura y la ubicación, construya la cadena correcta para que Seijo Alonso la grite a todo pulmon sin equivocarse.

Por ejemplo, si aparecen:

+ Kraken y Babor debe gritar: `Ahoy! capitán, Un Kraken a babor`

+ Leviatanes y Proa debe gritar: `Ahoy! capitán, unos leviatanes por la proa`

# ¿Que tienes para arrancar?
En el módulo utilidades.py se encuentran definidas dos funciones que serán de utilidad

+  `aparecer_criatura()` Que retorna una de las criaturas marinas en órden aleatorio

+  `aparecer_direccion()` Que retorna una de las criaturas marinas en órden aleatorio

+ En el archivo main.py hay una prueba del funcionamiento de estas funciones

# Iniciamos
Entonces tripulantes manos a la obra, con la carta de navegación IDEAL y la herramienta Python vamos a trabajar.








