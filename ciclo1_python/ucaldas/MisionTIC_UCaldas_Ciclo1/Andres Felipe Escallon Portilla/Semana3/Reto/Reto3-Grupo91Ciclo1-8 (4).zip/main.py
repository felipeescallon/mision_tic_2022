'''
DEBEN TRABAJAR SIMILARMENTE A LA METODOLOGÍA EMPLEADA EN LOS TALLERES:

-Este script main.py debe solicitar la información al usuario, hacer uso de las funciones alojadas en el script registro.py para validar la información, y finalmente mostrar al usuario el mensaje especificado al final del archivo README.md

-Recuerden que es necesario comentar adecuadamente el código donde consideren necesario hacerlo

-El reto se considera aprobado pasando exitosamente mínimo 4 de las 7 pruebas automáticas (tests)
'''
import registro as reg

#=======================================================
#E S P A C I O    D E    T R A B A J O     A L U M N O
#=======================================================

nombre = input("Ingrese nombre: ")
ident = int(input("Ingrese identificación: "))
correo = input("Ingrese correo: ")
sobrenombre = input("Ingrese sobrenombre: ")
clave = input("Ingrese clave:")
tiempo = int(input("Ingrese tiempo de experiencia (meses): "))
tratamiento = input("Está en tratmiento médico? (Si, No): ")
conocimiento = input("Tiene conocimiento en mecánica (Si, No): ")

val_nombre = reg.validar_nombre(nombre)
val_ident =  reg.validar_ident(ident)
val_correo = reg.validar_correo(correo)
val_sobrenombre =  reg.validar_sobrenombre(sobrenombre)
val_clave = reg.validar_clave(clave)

valido, criterio = reg.validar_informacion(val_nombre, val_ident, val_correo, val_sobrenombre, val_clave)

if valido:
  zona = reg.asignar_zona(tiempo, tratamiento, conocimiento)
  print("Nombre:", nombre)
  print("Identificación:", ident)
  print("Registro Exitoso!, Bienvenido a la Corporación Umbrella.")
  print("Tu zona asignada para la distribución de la vacuna es:", zona)
  print("Que tenga un Feliz Día!")
else:
  print("Registro No Exitoso,", criterio, "incorrecto.")
