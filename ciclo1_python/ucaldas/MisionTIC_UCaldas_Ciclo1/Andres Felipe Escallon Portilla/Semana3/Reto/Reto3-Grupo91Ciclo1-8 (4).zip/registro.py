'''
-Ustedes deben adaptar su solución a la plantilla presentada aquí, trabajando exactamente con el nombre de las variables, parámetros y retornos de las funciones que se les proporcionan a continuación, con el fin de facilitar su solución y calificación automática (es decir, es una ayuda como las que se proporcionan en el los laboratorios y talleres.

-Recuerden que es necesario comentar adecuadamente cada función.
'''

#=======================================================
#E S P A C I O    D E    T R A B A J O     A L U M N O
#=======================================================

def validar_nombre(nombre):
  #retorna un booleano
  return nombre.isalpha()


def validar_ident(identificacion):
  #retorna un booleano
  valor = False
  if 10000000 <= identificacion <= 100000000:
    valor = True
  return valor


def validar_correo(correo):
  #retorna un booleano
  valor = False
  if correo.count('@') == 1:
    valor = True
  return valor


def validar_sobrenombre(sobrenombre):
  #retorna un booleano
  valor = True
  if sobrenombre[0].isdigit() or sobrenombre.count('a') > 3:
    valor = False
  return valor


def validar_clave(clave):
  #retorna un booleano
  valor = False
  if clave.count('_') > 0 or clave.count('&') > 0 or clave.count('?') > 0:
    valor = True
  return valor


def asignar_zona(tiempo, tratamiento, conocimiento):
  #retorna un string con la zona
  anno = round(tiempo/12, 2)
  if 1 < anno <= 5 and tratamiento == 'No' and conocimiento == 'Si':
    zona = 'Sur'
  elif 1 < anno <= 5 and tratamiento == 'Si' and conocimiento == 'No':
    zona = 'Norte'
  elif anno > 5 and tratamiento == 'No' and conocimiento == 'Si':
    zona = 'Oriente'
  elif anno > 5 and tratamiento == 'Si' and conocimiento == 'Si':
    zona = 'Occidente'
  elif anno > 5 and tratamiento == 'No' and conocimiento == 'No':
    zona  = 'Sur Occidente'
  else:
    zona = 'Central'
  return zona


def validar_informacion(val_nombre, val_ident, val_correo, val_sobrenombre, val_clave):
  #retorna dos valores: booleano, parámetro(string)
  if val_nombre:
    valor = True
    criterio = 'ninguno'
    if val_ident:
      valor = True
      criterio = 'ninguno'
      if val_correo:
        valor = True
        criterio = 'ninguno'
        if val_sobrenombre:
          valor = True
          criterio = 'ninguno'
          if val_clave:
            valor = True
            criterio = 'ninguno'
          else:
            valor = False
            criterio = 'clave'
        else:
          valor = False
          criterio = 'sobrenombre'
      else:
        valor = False
        criterio = 'correo'
    else:
      valor = False
      criterio = 'ident'
  else: 
    valor = False
    criterio = 'nombre'
  return valor, criterio